PSD TEMPLATES

5 templates to create:
1. Full_Body_Hero.psd - 1024x1536, smart object for figure
2. Close_Up_Portrait.psd - 1024x1024, face detail layers
3. Dynamic_Pose.psd - 1024x1536, action composition
4. Tattoo_Flash.psd - 1024x1536, vertical layout
5. Album_Cover.psd - 1400x1400, square format

Each should include:
- Base collage layer (smart object)
- Watercolor bleed overlay
- Obsidian/mosaic layer
- Kintsugi line overlay
- Botanical elements
- Embroidery/beading detail
- Datamosh/glitch effects
- Lunarpunk glow atmosphere
