PSD TEMPLATES (10 Total)

1. Full_Body_Hero.psd
2. Close_Up_Portrait.psd
3. Dynamic_Pose.psd
4. Tattoo_Flash.psd
5. Album_Cover.psd
6. Fashion_Editorial.psd - 1024x1536, runway composition
7. Boro_Jumpsuit.psd - textile pattern layout
8. Mosaic_Armor.psd - hard panel construction
9. Bioluminescent_Cape.psd - flowing fabric study
10. Sacred_Profane_Diptych.psd - split composition

Plus Raw_Sources/ folder with unmerged layer files.
