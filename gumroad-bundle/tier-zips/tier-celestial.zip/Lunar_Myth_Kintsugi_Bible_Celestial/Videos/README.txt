VIDEO TUTORIALS

1. Quickstart_From_Prompt_to_Gallery.mp4
   - 20-minute walkthrough from prompt to finished piece

2. ComfyUI_Workflow_Walkthrough.mp4
   - Loading and using the included workflow JSONs

3. LoRA_Training_Start_to_Finish.mp4
   - Dataset prep, training, and testing your custom model

Record these as screen captures with voiceover.
